﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class Acosador_1 : MonoBehaviour
{

    //Declarar un arreglo de waypoints - Tipo Transform, publico

    //Declarar un int para recorrer el arreglo

    //Declarar una variable del tipo aidestiantionsetter

    // Start is called before the first frame update
    void Start()
    {
        //Obtener el componente de aidestiantionsetter

        //A la variable del tipo aidestinationsetter acceder a su variable target
        //  y darle valor del primer waypoint
    }

    // Update is called once per frame
    void Update()
    {
        //Calcular la distancia entre la posicion del acosador y el waypoint al cual se dirige

        //Preguntar si la posicion del acosador es igual o menor a la distancia
        //respecto al waypoint
            //Si es verdad
            
            //Sumar en uno al int que esta moviendose por el arreglo
            
            //Hay que ccontrar que cuando recorra todo el arreglo, se reinicie a la 
            //primera posicion del arreglo

            //Asignar a nuestra variable del tipo aidestinationsetter en su variable
            //target, el waypoint al cual dirigirse
    }
}
